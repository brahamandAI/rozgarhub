import { PrismaClient } from '@prisma/client';

declare global {
  var prisma: PrismaClient | undefined;
}

class PrismaSingleton {
  private static instance: PrismaClient;
  private static isInitialized = false;

  private constructor() {}

  public static getInstance(): PrismaClient {
    if (!PrismaSingleton.instance) {
      if (process.env.NODE_ENV === 'production') {
        PrismaSingleton.instance = new PrismaClient();
      } else {
        // In development, use the global instance to prevent multiple instances
        if (!global.prisma) {
          global.prisma = new PrismaClient({
            log: ['query', 'error', 'warn'],
          });
        }
        PrismaSingleton.instance = global.prisma;
      }
      PrismaSingleton.isInitialized = true;
    }

    return PrismaSingleton.instance;
  }

  public static async disconnect(): Promise<void> {
    if (PrismaSingleton.instance) {
      await PrismaSingleton.instance.$disconnect();
      PrismaSingleton.instance = undefined as any;
      PrismaSingleton.isInitialized = false;
    }
  }

  public static isConnected(): boolean {
    return PrismaSingleton.isInitialized;
  }
}

// Export a singleton instance
export const prisma = PrismaSingleton.getInstance();

// Export the singleton class for testing purposes
export { PrismaSingleton }; 